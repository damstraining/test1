package com.vsics;

public class Radio {
	public Radio() {
		System.out.println("Radio class 0 param constructor");
	}
}

package com.vsics;

public class Frequency {
  public Frequency() {
	System.out.println("Frequency class 0 param constructor");
}
}

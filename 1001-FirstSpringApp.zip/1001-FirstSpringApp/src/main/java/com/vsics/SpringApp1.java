package com.vsics;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringApp1 {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("spring-beans.xml");
       Radio  radio1= context.getBean("radio",Radio.class);
       Frequency  fr= context.getBean("radio1",Frequency.class);
       
       System.out.println(radio1.hashCode());
       System.out.println(fr.hashCode());
	}

}

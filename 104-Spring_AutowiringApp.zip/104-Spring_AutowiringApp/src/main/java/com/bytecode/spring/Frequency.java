package com.bytecode.spring;

public class Frequency {

	public String tune(float channelNumber) {
		return "tuning at " + channelNumber;
	}
}

package com.bytecode.spring;

public class Radio {

	private Frequency f;

	public Radio() {
		System.out.println("0 param constructor  executed");
	}

	public Radio(Frequency f) {
		System.out.println("1 param constructor  executed");
		this.f = f;
	}

	public void setF(Frequency f) {
		System.out.println("Setter method executed");
		this.f = f;
	}

	public String playSong(float channelNumber) {

		String res = f.tune(channelNumber);

		return res + " and playing song at " + channelNumber;
	}
}

package com.bytecode.spring;

public class Car {

}

package com.bytecode.spring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AutoWiringApp {

	public static void main(String[] args) {

		ApplicationContext context = new ClassPathXmlApplicationContext("spring-beans.xml");
		Radio obj1 = context.getBean("radio", Radio.class);
		Radio obj2 = context.getBean("radio", Radio.class);
		System.out.println(obj1.hashCode());
		System.out.println(obj2.hashCode());
		String res = obj1.playSong(98.7f);
		System.out.println(res);
	}

}

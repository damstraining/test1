package com.bank.icici.main;
import com.bank.icici.card.CreditCard;
import com.bank.icici.account.Customer;
class App 
{
	public static void main(String[] args) 
	{
		Customer  cus1=new Customer("Raja","salaried");

		Customer  cus2=new Customer("Rani","business");

		CreditCard  c1=new CreditCard(cus1);
		CreditCard  c2=new CreditCard(cus2);

		c1.setCardLimit(200000);

		c1.assignCreditCard();
		c2.assignCreditCard();
	}
}

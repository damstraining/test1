package p2;
import p1.*;
public class  ProtectedDemo2 
{
	public static void main(String... args) 
	{
		ProtectedDemo1  obj1=new ProtectedDemo1();
		obj1.m1();
	}
}

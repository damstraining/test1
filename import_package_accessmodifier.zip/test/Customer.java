package com.bank.icici.account;
public class  Customer
{
	private String customerName;
	private String customerType;

	public Customer(String customerName,String customerType){
		this.customerName=customerName;
		this.customerType=customerType;
	}

	public String getCustomerType(){
		return customerType;
	}

	public String getCustomerName(){
		return customerName;
	}
}

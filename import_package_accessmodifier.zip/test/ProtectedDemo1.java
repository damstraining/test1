package p1;
public class  ProtectedDemo1
{
	void m1() 
	{
		System.out.println("This is protected m1 method");
	}
}

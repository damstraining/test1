package com.bank.icici.card;
import com.bank.icici.account.Customer;
public class  CreditCard
{
   private double cardLimit;
   private Customer  customer;

   public CreditCard(Customer  customer){
	  this.customer=customer;
   }

   public void  setCardLimit(double cardLimit){
	  this.cardLimit=cardLimit;
   }

   public void assignCreditCard(){
	   String  type=customer.getCustomerType();

	   if(type.equals("salaried")){
		   System.out.println("card assigened to "+ customer.getCustomerName() +" with limit "+cardLimit);
	   }
	   else{
		  System.out.println("Card declined  to "+customer.getCustomerName());
	   }
   }
}

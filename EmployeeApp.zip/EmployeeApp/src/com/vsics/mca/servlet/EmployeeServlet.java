package com.vsics.mca.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class EmployeeServlet extends HttpServlet {
	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		// set mimeType
		res.setContentType("text/html");
		// get PrintWriter object

		PrintWriter printWriter = res.getWriter();

		// reading form data
		String eid = req.getParameter("id");
		String ename = req.getParameter("name");
		String deptId = req.getParameter("dept");
		String salary = req.getParameter("sal");

		// convert above data to sql required form

		int id = Integer.parseInt(eid);
		int dept = Integer.parseInt(deptId);
		double sal = Double.parseDouble(salary);
		// insert above record to employee table
		// step-1 load the driver class
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");

			// create the Connection object
			Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "mca1", "mca2");
			// prepare sql query

			final String INSERT_EMP_DATA = "insert into emp_record values(?,?,?,?)";

			// create PreparedStatement object
			PreparedStatement preparedStatement = connection.prepareStatement(INSERT_EMP_DATA);

			// set form data to place holder or place resolver ?

			preparedStatement.setInt(1, id);
			preparedStatement.setString(2, ename);
			preparedStatement.setInt(3, dept);
			preparedStatement.setDouble(4, sal);

			// execute the sql query
			int result = preparedStatement.executeUpdate();

			if (result == 0) {
				printWriter.println("<h1 style='color:red'>Record Not inserted for employee id " + id + "</h1>");
			} else {
				printWriter.println("<h1 style='color:green'>Record  inserted for employee id " + id + "</h1>");
			}

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}

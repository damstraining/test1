package com.vsics.exception;

import com.vsics.entity.Account;
import com.vsics.entity.Customer;

public class ExceptionDemo1 {

	public static void main(String[] args)  {

		Account account = new Account(111222, 10000);
		Customer customer = new Customer(101, "rani", "kanpur", "1234567890", account);
		//customer.checkBalance();
		
		//account.creditBalance(5000,111222 );
		//account.debitBalance(2000,111222 );
		
		try {
			account.debitBalance(2000,111222 );
		} catch (InvalidAccountNumber e) {
			e.printStackTrace();
		}
		
		account.creditBalance(4000, 111223);
		
		
		
		
	}
}

package com.vsics.exception;

public class InvalidCustomer extends RuntimeException {
	public InvalidCustomer(String s1) {
		super(s1);
	}
}

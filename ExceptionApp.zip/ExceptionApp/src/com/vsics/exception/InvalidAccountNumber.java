package com.vsics.exception;

/*
 *   Throwable , Exception--->checked exception==>compiler
 *   
 *   RuntimeException--->uncheked exception
 * */
public class InvalidAccountNumber extends Exception {
	public InvalidAccountNumber(String msg) {
		super(msg);
	}
}

package com.vsics.entity;

import com.vsics.exception.InvalidAccountNumber;

public class Account {
	private long accountNumber;
	private double availableBalance;

	public Account(long accountNumber, double availableBalance) {
		this.accountNumber = accountNumber;
		this.availableBalance = availableBalance;
	}

	public void debitBalance(double debitAmt, long accountNumber) throws InvalidAccountNumber {
		if (accountNumber == 111222) {
			availableBalance = availableBalance - debitAmt;
			System.out.println("available balance is=" + availableBalance);
		} else {
			throw new InvalidAccountNumber("Invalid Account number " + accountNumber);
		}
	}

	public void creditBalance(double creditAmt, long accountNumber) {
		if (accountNumber == 111222) {
			availableBalance = availableBalance + creditAmt;
			System.out.println("available balance is=" + availableBalance);
		} else {
			try {
			throw new InvalidAccountNumber("Invalid Account number " + accountNumber);
		  //  int  a=10;
			}catch (InvalidAccountNumber e) {
				System.out.println(e.getMessage());
			}
		}
	}

	public long getAccountNumber() {
		return accountNumber;
	}

	public double getAvailableBalance() {
		return availableBalance;
	}
}

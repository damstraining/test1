package com.vsics.entity;

import com.vsics.exception.InvalidCustomer;

public class Customer {
	private int cid;
	private String cName;
	private String address;
	private String phoneNumber;

	private Account account;

	public Customer(int cid, String cName, String address, String phoneNumber, Account account) {
		this.cid = cid;
		this.cName = cName;
		this.address = address;
		this.phoneNumber = phoneNumber;
		this.account = account;
	}

	public void checkBalance() {
		if (cName.equalsIgnoreCase("raja") == true) {
			System.out.println("Hi " + cName + " available balance is your number " + account.getAccountNumber()
					+ "  is " + account.getAvailableBalance());
		}
		else {
			throw new InvalidCustomer("customer not available in db");
		}

	}
	
	

}

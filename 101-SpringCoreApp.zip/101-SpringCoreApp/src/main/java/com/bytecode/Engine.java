package com.bytecode;

public class Engine {
	public Engine() {
		System.out.println("engine class constructor");
	}

	public void start() {

		System.out.println("Engine started");

	}
}

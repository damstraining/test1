package com.bytecode;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {

	public static void main(String[] args) {
		// create container class object

		ApplicationContext context = new ClassPathXmlApplicationContext("spring-beans.xml");
		Car car1 = context.getBean("car", Car.class);
		car1.move();

	}

}

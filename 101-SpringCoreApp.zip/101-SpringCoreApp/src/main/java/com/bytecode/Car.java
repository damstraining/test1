package com.bytecode;

public class Car {

	private Engine engine;

	public Car() {

		System.out.println("car class 0 param constructor");
	}

	public void move() {
		engine.start();
		System.out.println("car is moving --happy journey");
	}

	public void setEngine(Engine engine) {

		this.engine = engine;
	}
}

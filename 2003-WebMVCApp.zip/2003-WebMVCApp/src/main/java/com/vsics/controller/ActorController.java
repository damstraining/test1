package com.vsics.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.vsics.entity.Actor;
import com.vsics.service.ActorService;

@Controller
public class ActorController {
	
	@Autowired
	private ActorService actorService;

	@GetMapping("/register")
	public String actorRegistartionForm() {

		return "actor_registration_form";
	}

	@PostMapping("/saveActor")
	public String saveActorData(@ModelAttribute Actor actor,Model model) {
        model.addAttribute("a1", actor);
        actorService.storeActorRecord(actor);
		return "show_actor_data";
	}
	
	@GetMapping("/actor/{id}")
	public String findActorById(@PathVariable(name = "id") Integer integer,Model model) {
		  
		Actor actor=actorService.getActorById(integer);
		model.addAttribute("a1", actor);
		return "show_actor_data";
	}
	
	@GetMapping("/delete/{id}")
	@ResponseBody
	public String deletActor(@PathVariable(name = "id") Integer integer) {
		actorService.deleteActorById(integer);
		return "record deleted for "+integer;
	}
	
}

package com.vsics.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vsics.entity.Actor;
import com.vsics.repository.ActorRepository;

@Service
public class ActorService {

	@Autowired
	private ActorRepository actorRepository;

	public String storeActorRecord(Actor actor) {
		actorRepository.save(actor);
		return "datasaved successfully";
	}

	public Actor getActorById(Integer integer) {
		Optional<Actor> optional = actorRepository.findById(integer);
		Actor actor = null;
		if (optional.isPresent()) {
			actor = optional.get();
		}
		return actor;
	}
	
	public void deleteActorById(Integer integer) {
		 actorRepository.deleteById(integer);
	}
}

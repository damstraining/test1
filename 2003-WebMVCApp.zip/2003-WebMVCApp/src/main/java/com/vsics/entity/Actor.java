package com.vsics.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

//This is binding class for form and Entity class as well of Table
@Entity
public class Actor {

	@Id  //for primary key
	@GeneratedValue(strategy = GenerationType.AUTO)//to generate automatically
	private Integer id;

	private String name;
	private String address;

	public Actor() {
		System.out.println("zero param constructor");
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		System.out.println("getter");
		return name;
	}

	public void setName(String name) {
		System.out.println("setter");
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Actor [id=" + id + ", name=" + name + ", address=" + address + "]";
	}
}

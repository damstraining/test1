package com.vsics.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.vsics.entity.Book;
import com.vsics.repository.BookRepository;

@RestController
public class BookController {

	@Autowired
	private BookRepository bookRepository;

	@GetMapping("/book/{id}")
	public ResponseEntity<Book> getBook(@PathVariable(name = "id") Integer integer) {

		Optional<Book> optional = bookRepository.findById(integer);
		Book book = null;
		if (optional.isPresent()) {
			book = optional.get();
		}
		return new ResponseEntity<Book>(book, HttpStatus.OK);
	}
	
	@GetMapping("/books")
	public List<Book> getBooks() {

		List<Book> books = (List<Book>) bookRepository.findAll();
		
		return books;
	}

	@PostMapping("/save")
	public ResponseEntity<Book> saveBook(@RequestBody Book book) {
		Book book1 = bookRepository.save(book);
		return new ResponseEntity<Book>(book1, HttpStatus.OK);

	}
	
	@PostMapping("/saveBooks")
	public ResponseEntity<Book> saveBooks(@RequestBody List<Book> books) {
		 bookRepository.saveAll(books);
		return new ResponseEntity<Book>(HttpStatus.OK);

	}
	
	
	@PutMapping("/book/{id}")
	public ResponseEntity<Book> updateBook(@RequestBody Book book ,@PathVariable(name = "id") Integer integer) {

		Optional<Book> optional = bookRepository.findById(integer);
		Book book1 = null;
		if (optional.isPresent()) {
			book1 = optional.get();
		}
		book1.setBookName(book.getBookName());
		book1.setAuthorName(book.getAuthorName());
		book1.setPrice(book.getPrice());
		bookRepository.save(book1);
		return new ResponseEntity<Book>(book1, HttpStatus.OK);
	}
	
	@DeleteMapping("/delete/{id}")
	public void deleteBookById(@PathVariable(name = "id") Integer integer) {
		bookRepository.deleteById(integer);
		
	}
}

package com.vsics.beans;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "Stu_table")
public class Student {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer studentId;

	@Column(name = "sname")
	private String studentName;

	private String studentAddress;

	private Long phoneNumber;

	public Student() {
		System.out.println("0,param constructor");
	}

	public Student(String studentName, String studentAddress, Long phoneNumber) {
		this.studentName = studentName;
		this.studentAddress = studentAddress;
		this.phoneNumber = phoneNumber;
	}

	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", studentName=" + studentName + ", studentAddress=" + studentAddress
				+ ", phoneNumber=" + phoneNumber + "]";
	}

}

package com.vsics;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.vsics.beans.Student;
import com.vsics.reposioty.StudentRepository;

@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(Application.class, args);
		System.out.println(context.getClass().getName());
		System.out.println("hello");

		StudentRepository repository = context.getBean("studentRepository", StudentRepository.class);
		System.out.println(repository.getClass().getName());

		Student s1 = new Student("Raja", "Kanpur", 1234567890L);
		Student s2 = new Student("Rani", "Lucknow", 9876543210L);
		Student s3 = new Student("Ramesh", "Kanpur", 1234567890L);
		Student s4 = new Student("Suresh", "Lucknow", 9876543210L);
		/*
		 * repository.save(s1); repository.save(s2);
		 */

		repository.saveAll(Arrays.asList(s1, s2,s3,s4));

		/*
		 * Optional<Student> stu=repository.findById(2); if (stu.isPresent()) {
		 * System.out.println(stu); }
		 */

		// first way to print list of studentss
		List<Student> students = repository.findAll();

		//students.forEach(x -> System.out.println(x));
		
		//second way by using for each loop
		/*
		 * for (Student student : students) { System.out.println(student); }
		 */
		
		
		//third way
		
		/*
		 * Iterator<Student> iterator=students.iterator();
		 * 
		 * while (iterator.hasNext()) { Student student = (Student) iterator.next();
		 * System.out.println(student); }
		 */
		
		//4thway
		
		for (Iterator iterator2 = students.iterator(); iterator2.hasNext();) {
			Student student = (Student) iterator2.next();
			System.out.println(student);
		}
	}

}

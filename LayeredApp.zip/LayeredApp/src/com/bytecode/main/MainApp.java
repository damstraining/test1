package com.bytecode.main;

import com.bytecode.bo.AdditionBO;
import com.bytecode.dao.AdditionDAO;
import com.bytecode.dto.AdditionDTO;
import com.bytecode.service.AdditionService;
import com.bytecode.vo.AdditionVO;

public class MainApp {

	public static void main(String[] args) {

		AdditionVO vo = new AdditionVO();
		vo.setNum1(args[0]);
		vo.setNum2(args[1]);

		AdditionDTO additionDTO = new AdditionDTO();
		additionDTO.setNum1(Integer.parseInt(vo.getNum1()));
		additionDTO.setNum2(Integer.parseInt(vo.getNum2()));

		AdditionService additionService = new AdditionService(additionDTO);
		AdditionBO additionBO = new AdditionBO();
		additionService.add(additionBO);

		AdditionDAO additionDAO = new AdditionDAO();
		additionDAO.setAdditionBO(additionBO);

		additionDAO.store();

	}

}

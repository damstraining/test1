package com.bytecode.service;

import com.bytecode.bo.AdditionBO;
import com.bytecode.dto.AdditionDTO;

public class AdditionService {

	private AdditionDTO additionDTO;

	public AdditionService(AdditionDTO additionDTO) {
		this.additionDTO = additionDTO;
	}

	public void add(AdditionBO additionBO) {
		additionBO.setSum(additionDTO.getNum1() + additionDTO.getNum2());

	}
}

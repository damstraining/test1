package com.bytecode.dao;

import com.bytecode.bo.AdditionBO;

public class AdditionDAO {
	private AdditionBO additionBO;

	public void setAdditionBO(AdditionBO additionBO) {
		this.additionBO = additionBO;
	}

	public void store() {
		int result = additionBO.getSum();
		System.out.println(result);
	}
}

package com.vsics.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class DateServlet extends GenericServlet {

	public DateServlet(int a) {

	}

	public DateServlet() {
		System.out.println("zero param constructor");
	}

	@Override
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {

		// Set MIME type
		res.setContentType("text/html");

		// get PrintWriter Object

		PrintWriter printWriter = res.getWriter();

		Date date = new Date();

		printWriter.println("<h1>  current date and time is ::" + date + "</h1>");

		printWriter.println("<a href='http://localhost:6161/DateApp/'> Go to home </a>");

		printWriter.close();

	}

}

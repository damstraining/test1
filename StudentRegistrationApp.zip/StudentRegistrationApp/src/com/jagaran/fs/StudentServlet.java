package com.jagaran.fs;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class StudentServlet extends HttpServlet {
	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html");

		PrintWriter pw = res.getWriter();

		// read form data
		String sid = req.getParameter("id");
		int stuId = Integer.parseInt(sid);
		String name = req.getParameter("name");
		String address = req.getParameter("add");
		String phoneNumber = req.getParameter("phone");
		long phone = Long.parseLong(phoneNumber);
		String email = req.getParameter("email");

		// load the driver class
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			// create the Connection obje3ct
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "vsics", "vsics");
			// prepare sql query
			String INSERT_STU_RECORD = "insert into student values(?,?,?,?,?)";

			// get PreparesStatement object

			PreparedStatement ps = con.prepareStatement(INSERT_STU_RECORD);
			ps.setInt(1, stuId);
			ps.setString(2, name);
			ps.setString(3, address);
			ps.setLong(4, phone);
			ps.setString(5, email);

			int result = ps.executeUpdate();

			if (result == 0) {
				pw.println("<h1> record not inserted for " + stuId + "</h1>");
			} else {
				pw.println("<h1> record  inserted foFr " + stuId + "</h1>");
			}

		} catch (ClassNotFoundException e) {

			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}

package com.vsics;

import java.util.List;
import java.util.Set;

public class Car {
	private int carId;
	private Set<String> carNames;
	private double price;
	private boolean active;

	public Car() {
		System.out.println("0 param constructor");
	}

	public int getCarId() {
		return carId;
	}

	public void setCarId(int carId) {
		this.carId = carId;
	}

	public Set<String> getCarName() {
		return carNames;
	}

	public void setCarNames(Set<String> carNames) {
		this.carNames = carNames;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public Car(int carId, Set<String> carNames, double price, boolean active) {
		System.out.println("parameterized constructor");
		this.carId = carId;
		this.carNames = carNames;
		this.price = price;
		this.active = active;
	}

	@Override
	public String toString() {
		return "Car [carId=" + carId + ", carName=" + carNames + ", price=" + price + ", active=" + active + "]";
	}

}

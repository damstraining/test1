package com.bytecode;

public interface IPayment {
	public abstract String pay(double amount);
}

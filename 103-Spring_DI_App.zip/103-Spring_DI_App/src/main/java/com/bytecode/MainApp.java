package com.bytecode;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("spring-beans.xml");
		BillCollector billCollector = context.getBean("billCollector", BillCollector.class);
		String result = billCollector.collectBill(2000);
		System.out.println(result);
	}

}

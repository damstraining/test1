package com.bytecode;

public class AmexCardPayment implements IPayment
{
	public String pay(double amount){
		
		return "amount "+amount +" paid using amex card";
	}
}


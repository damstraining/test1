package com.bytecode;

public class BillCollector {
	private IPayment ipayment;
	
	public BillCollector(IPayment ipayment) {
		System.out.println("Bill collector 1 param constructor");
		this.ipayment = ipayment;
	}

	public BillCollector() {
		System.out.println("Bill collector 0 param constructor");
	}

	public void setIpayment(IPayment ipayment) {
		System.out.println("bill collector setter methodF");
		this.ipayment = ipayment;
	}

	public String collectBill(double bal) {
		String result = ipayment.pay(bal);
		return result;
	}
}

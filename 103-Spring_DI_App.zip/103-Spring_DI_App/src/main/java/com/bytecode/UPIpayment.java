package com.bytecode;

public class UPIpayment implements IPayment
{
	public String pay(double amount){
		
		return "amount "+amount +" paid using upi";
	}
}

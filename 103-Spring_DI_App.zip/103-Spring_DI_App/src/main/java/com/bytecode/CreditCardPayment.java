package com.bytecode;

public class CreditCardPayment implements IPayment
{
	public CreditCardPayment() {
		System.out.println("credit card 0 param constructor");
	}
	public String pay(double amount){
		
		return "amount "+amount +" paid using Credit card";
	}
}

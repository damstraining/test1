package com.bytecode;

public class DebitCardPayement implements IPayment
{
	public DebitCardPayement() {
		System.out.println("debit card 0 param constructor");
	}
	public String pay(double amount){
		
		return "amount "+amount +" paid using debit card";
	}
}

/*
    String class constructors:
	--------------------------


*/

class  StringDemo10
{
	public static void main(String[] args) 
	{
		/*
		String  s1=new String();

		String  s2=new String("java");

		System.out.println("s2 =>"+s2);

		StringBuffer  sb1=new StringBuffer("java ");//mutable

		sb1.append("program ");
		sb1.append("at dams");

		System.out.println(sb1);

		String  s3=new String(sb1);

		System.out.println(s3);

		String  s4=s3.concat("at vsics");

		System.out.println(s3);

		System.out.println(s4);

		
        
		
        char[]  ch={'j','a','v','a'};

		String  s1=new String(ch);

		System.out.println(s1);

		*/

		byte[]   b={97,98,99,100,101};

		String  s1=new String(b);

		System.out.println(s1);
	}
}

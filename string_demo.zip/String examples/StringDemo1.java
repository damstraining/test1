/*
     String Handling in java: (M. Imp)
	 ---------------------------------

	 sequence of characters within double quotes is called string literals.

	 "kayum"
	 "kanpur"
	 "dams"

	 String
	 StringBuffer
	 StringBuilder

	 ------------------------------------------------------------------

	 
*/

class  StringDemo1
{
	public static void main(String[] args) 
	{
		String s1="dams";
		String s2=new String("dams");
		StringBuffer s3=new StringBuffer("dams");
		StringBuilder s4=new StringBuilder("dams");

		System.out.println("s1="+s1);
		System.out.println("s2="+s2);
		System.out.println("s3="+s3);
		System.out.println("s4="+s4);
	}
}

class StringDemo5 
{
	public static void main(String[] args) 
	{
		String s1=new String("java");

		String s2=s1.concat("program");

		String s3="javaprogram";
		String s4="javaprogram";

		System.out.println("s2==s3 =>"+(s2==s3));
		System.out.println("s4==s3 =>"+(s4==s3));
	}
}

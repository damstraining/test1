/*
   java.lang.Object
          |
          |-public   String  toString(){
		          ClassName@hexadecimalNumber
		    }


	class  String  extends Object{
	    
		    public   String  toString(){
		         object content
		    }
	    
	}
*/
class Student
{
    String studentName;
    int rollNumber;
    
	Student(String studentName,int rollNumber){
		this.studentName=studentName;
		this.rollNumber=rollNumber;
	}
   
    void  displayStudentData(Student  stu){
		System.out.println(stu);
    }

	public String  toString(){
		return "[  student name "+studentName  +"  || student roll number "+ rollNumber +" ]";
	}
}


class  StringDemo11
{
	/*
	String  s;
    StringDemo11(String  s){
		this.s=s;
    }

	public String  toString(){
		return s;
	}
*/
	public static void main(String[] args) 
	{
		/*
		StringDemo11  sd=new StringDemo11("java");
		System.out.println("sd= "+sd);
		System.out.println("sd.toString()= "+sd.toString());

		String  s1=new String("kayum");
		System.out.println("s1= "+s1);
		System.out.println("s1.toString()= "+s1.toString());

		*/

         Student  s1=new Student("Raja",101);
		 Student  s2=new Student("Rani",102);

		 s1.displayStudentData(s1);
		 s2.displayStudentData(s2);
		 
		 
	}
}

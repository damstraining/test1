/*
    .equals():
	===========


*/

class  StringDemo3
{
	public static void main(String[] args) 
	{
		String  s1=new String("java");
		String  s2=new String("java");

		System.out.println("s1="+s1);
		System.out.println("s2="+s2);
		System.out.println("s1.equals(s2)="+s1.equals(s2));


		StringBuffer  s3=new StringBuffer("java");
		StringBuffer  s4=new StringBuffer("java");

		System.out.println("s3="+s3);
		System.out.println("s4="+s4);
		System.out.println("s3.equals(s4)="+s3.equals(s4));
	}
}

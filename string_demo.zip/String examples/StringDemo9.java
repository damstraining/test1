//exceptional
class StringDemo9 
{
	public static void main(String[] args) 
	{
		String s1=new String("java");

		String  s2=s1.concat("program");

		String  s3=s2.intern();

		String  s4="javaprogram";

		System.out.println("s3="+s3);
		System.out.println("s2="+s2);
		System.out.println("s4="+s4);

		System.out.println("s3==s4 =>"+(s3==s4));
		System.out.println("s3==s2 =>"+(s3==s2));
		System.out.println("s3==s4 =>"+(s3==s4));
	}
}

/*
    Special memory--->SCP (String constant pool)

    String  s1="java";//1 object

	String  s2=new String("java");//2 object

*/

class  StringDemo4
{
	public static void main(String[] args) 
	{
         String  s1="java";
		 String  s2="java";

		 String  s3=new String("java");
		 String  s4=new String("java");

		System.out.println("s1 ="+s1);
		System.out.println("s2 ="+s2);
		System.out.println("s3 ="+s3);
		System.out.println("s4 ="+s4);

		System.out.println("s1==s2 =>"+(s1==s2));
		System.out.println("s3==s4 =>"+(s3==s4));
	}
}

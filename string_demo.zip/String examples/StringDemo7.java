class StringDemo7 
{
	public static void main(String[] args) 
	{
		final String   s3="java";

		String   s1=s3+"program";


		String   s2="javaprogram";

		System.out.println(s1==s2);
	}
}

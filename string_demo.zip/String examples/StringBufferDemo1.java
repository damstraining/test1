/*
  
*/
class  StringBufferDemo1
{
	public static void main(String[] args) 
	{
		StringBuffer  sb1=new StringBuffer("java");

		System.out.println("sb1.capacity() ::"+sb1.capacity());

		sb1.append("abcdefghijklmnop");

		System.out.println("sb1.capacity() ::"+sb1.capacity());

		sb1.append("q");

		System.out.println("sb1.capacity() ::"+sb1.capacity());



	}
}

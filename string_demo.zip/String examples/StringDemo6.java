class StringDemo6 
{
	public static void main(String[] args) 
	{
		String  s1="java";

		String  s2=s1.concat("program");

		System.out.println("s2="+s2);

		final String  s3="java";

		String s4= s3.concat("program");
		System.out.println("s4="+s4);
        String  s6=s5+"program";


		final String  s5="java";

		String  s9="java"+"program";//scp

		String  s8=s5+"program";  //scp

		System.out.println("s6="+s6);

		String  s7="javaprogram";


		System.out.println(s2==s7);
		System.out.println(s4==s7);
		System.out.println(s6==s7);


	}
}

package com.bytecode.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.bytecode.model.Student;
import com.bytecode.service.StudentService;

@Controller
@RequestMapping("/student")
public class StudentController {
	
	@Autowired
	private StudentService service;
     
	@GetMapping("/form") //http://localost:9091/student/form
	public  String  showForm() {
		
		return "form";
	}
	
	@PostMapping("/add")
	public String saveStudent(@ModelAttribute Student student,Model model) {
		Student  student2= service.addStudent(student);
		model.addAttribute("s", student2);
		return "show";
	}
	
	
	@GetMapping("/all")
	public String getAllStudents(Model model) {
		List<Student> students=service.fetchAllStudents();
		model.addAttribute("s", students);
		return "show";
	}
	
}

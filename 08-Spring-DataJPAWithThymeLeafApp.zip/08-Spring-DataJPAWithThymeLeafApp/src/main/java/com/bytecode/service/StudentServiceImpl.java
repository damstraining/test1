package com.bytecode.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bytecode.model.Student;
import com.bytecode.repository.StudentRepository;

@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	private StudentRepository repository;

	@Override
	public Student addStudent(Student student) {
		Student student2 = repository.save(student);
		return student2;
	}

	@Override
	public String updateStudent(Student student, Integer id) {

		return null;
	}

	@Override
	public void deleteStudent(Integer id) {

	}

	@Override
	public Student fetchStudentById(Integer id) {

		return null;
	}

	@Override
	public List<Student> fetchAllStudents() {
		List<Student> list = (List<Student>) repository.findAll();
		return list;
	}

}

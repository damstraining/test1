package com.bytecode.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.bytecode.model.Student;

@Service
public interface StudentService {
	public Student addStudent(Student student);

	public String updateStudent(Student student, Integer id);

	public void deleteStudent(Integer id);

	public Student fetchStudentById(Integer id);

	public List<Student> fetchAllStudents();
}
